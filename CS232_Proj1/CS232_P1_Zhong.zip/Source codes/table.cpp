/**************************************************************************
 * File name: table.cpp
 * --------------------
 * This file contains just an include line since the Table class doesn't
 * have any non-templated functions.
 *
 * Programmer: Jian Zhong
 * Date Written: 10/01/2020
 * Date Last Revised: 10/14/2020
 **************************************************************************/

#include "table.h"
